@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public void registerUser(UserDto userDto) {
        // Perform validation and save user to the database
        // You may also want to hash the password before storing it
        userRepository.save(new User(userDto.getUsername(), userDto.getPassword()));
    }
}
