@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public boolean validateUser(UserDto userDto) {
        // Perform validation by checking the user's credentials in the database
        Optional<User> userOptional = userRepository.findByUsernameAndPassword(userDto.getUsername(), userDto.getPassword());
        return userOptional.isPresent();
    }
}
